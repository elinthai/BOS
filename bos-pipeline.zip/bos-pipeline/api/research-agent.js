// api/research-agent.js
// Step 2 checkpoint: POST { "niche": "We help X get Y" } to /api/research-agent.
// Calls Claude with the Research Agent's exact spec, writes each validated idea
// as a new row in Content Repository with Status = "Idea" — nothing auto-publishes.
const Anthropic = require("@anthropic-ai/sdk");
const { appendRow } = require("../lib/sheets");

const SYSTEM_PROMPT = `
You validate content demand before anything gets scripted. You never hand over an idea
that isn't backed by real evidence of an audience wanting it.

Given a niche statement ("We help [audience] achieve [outcome]"), generate 8-10 real
search phrases the audience actually types. Never invent view counts, subscriber counts,
or quotes. Score ideas using this filter: 100,000+ views, under 100,000 subscribers,
5:1+ views-to-subscriber ratio, average production quality.

Return ONLY valid JSON, no preamble, no markdown fences, in this exact shape:
{
  "ideas": [
    { "topic": "...", "searchPhrase": "...", "searchVolume": "High|Med|Low",
      "difficulty": "High|Med|Low", "contentPillar": "...", "funnelStage": "Top|Middle|Bottom" }
  ]
}
Return at most 10 ideas. If you can't validate real demand without live search, still
return your best structured ideas but keep searchVolume conservative (Low/Med) rather
than guessing High.
`.trim();

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).json({ ok: false, error: "POST only" });
  }
  const { niche, businessUnit } = req.body || {};
  if (!niche) {
    return res.status(400).json({ ok: false, error: "Missing 'niche' in request body" });
  }

  try {
    const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 2000,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: niche }],
    });

    const text = response.content.find((b) => b.type === "text")?.text || "{}";
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    const today = new Date().toISOString().split("T")[0];
    for (const idea of parsed.ideas || []) {
      await appendRow("Content Repository", [
        "", idea.topic, idea.searchPhrase, idea.searchVolume, idea.difficulty,
        "", businessUnit || "", idea.funnelStage, idea.contentPillar, "",
        "", "", "", "", "Idea", "", "", today,
      ]);
    }

    res.status(200).json({ ok: true, count: (parsed.ideas || []).length, ideas: parsed.ideas });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};
