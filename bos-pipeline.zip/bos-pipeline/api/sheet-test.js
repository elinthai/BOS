// api/sheet-test.js
// Step 1 checkpoint: hit /api/sheet-test in a browser after deploying.
// If it returns your two example rows from the Content Repository tab, the connection works.
const { getRows } = require("../lib/sheets");

module.exports = async (req, res) => {
  try {
    const rows = await getRows("Content Repository", "A1:F5");
    res.status(200).json({ ok: true, rows });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
};
