# BOS Pipeline — Vercel Starter

Two working pieces so far: a Sheet-connection test, and a real Research Agent
that writes validated ideas straight into your Content Repository tab.
Everything else (Script, Packaging, Launch, Repurpose, Revenue, Analytics,
Knowledge) follows the exact same pattern once this is proven live.

## Why a Service Account (not the OAuth login flow)

n8n's Google Sheets setup uses OAuth (sign in with your Google account) because
it's built for a person clicking through a UI. A Vercel function has no UI and
no one to click "Allow" — it needs to authenticate on its own, every time,
automatically. A Service Account is Google's way of giving a *program* its own
identity to sign in with. You create it once, share your Sheet with it like
you'd share with a colleague, and every deploy afterward just works with no
re-authentication.

## Setup — do this once

### 1. Create a Google Service Account
1. Go to https://console.cloud.google.com and create a project (or use an existing one).
2. Left sidebar → **APIs & Services → Library** → search "Google Sheets API" → **Enable**.
3. Left sidebar → **APIs & Services → Credentials** → **Create Credentials → Service Account**.
4. Give it any name (e.g. `bos-pipeline`) → Create and Continue → Done.
5. Click the new service account → **Keys** tab → **Add Key → Create new key → JSON**.
   A `.json` file downloads. Open it — you need two fields from it: `client_email` and `private_key`.

### 2. Share your Sheet with the service account
1. Open your Content Repository Google Sheet.
2. Click **Share** → paste the `client_email` value from the JSON file (looks like
   `bos-pipeline@your-project.iam.gserviceaccount.com`) → give it **Editor** access.
   Without this step, the service account can authenticate but still can't touch your data.

### 3. Get a Claude API key
Go to https://console.anthropic.com → **API Keys** → create one. This is separate
from your claude.ai chat login — it's billed per use, not part of a Pro/Max plan.

### 4. Push this folder to GitHub
```bash
cd bos-pipeline
git init
git add .
git commit -m "BOS pipeline starter"
git remote add origin <your-new-repo-url>
git push -u origin main
```
`.env.example` is safe to commit — it has no real secrets. Never commit an actual `.env` file.

### 5. Import into Vercel
1. https://vercel.com/new → import the GitHub repo you just pushed.
2. Before the first deploy, go to **Project Settings → Environment Variables** and add:
   - `GOOGLE_SERVICE_ACCOUNT_EMAIL` — the `client_email` from your JSON key
   - `GOOGLE_PRIVATE_KEY` — the `private_key` value, exactly as it appears in the JSON
     (keep the `\n` characters literally as text — the code converts them back automatically)
   - `SHEET_ID` — `1iOzxtPaSBh-mRo546qTgIw5zY6TunyQ84h6gVmXip4E`
   - `ANTHROPIC_API_KEY` — your key from step 3
3. Deploy.

## Test it — two checkpoints, in order

**Checkpoint A — does the Sheet connection work at all?**
Visit `https://your-project.vercel.app/api/sheet-test` in a browser.
- Success looks like: `{"ok":true,"rows":[[...your header row...],[...row 1...]]}`
- If you get an error instead, it's almost always the Sheet-sharing step (2) or a
  malformed `GOOGLE_PRIVATE_KEY` env var — check those two first.

**Checkpoint B — does the Research Agent work end to end?**
Send a POST request (Postman, curl, or any REST client) to
`https://your-project.vercel.app/api/research-agent` with body:
```json
{ "niche": "We help Samui-based expats fix chronic lower back pain through Thai-rooted yoga therapy", "businessUnit": "SYT" }
```
Success = new rows appear in your Content Repository tab with Status = "Idea".
Nothing else happens automatically — no scripts get written, nothing publishes.
This endpoint only drafts and logs; every later stage still needs your review.

## What's deliberately not built yet

Only Research Agent is live. Script, Packaging, Launch, Repurpose, Revenue,
Analytics, and Knowledge Capture aren't wired up — same pattern, but I'd rather
you confirm these two checkpoints work against your real Sheet and your real
API key before we wire up six more endpoints on the same assumptions.
